<template>
    <footer class="h-12 bg-gray-100 text-centre flex item-center justify-center text-sm ">
        © 2025 My Store All rights reserved
    </footer>
</template>