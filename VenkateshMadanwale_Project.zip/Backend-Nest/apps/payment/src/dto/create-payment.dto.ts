export class CreatePaymentDto {
  emailid: string;
  transaction: any;
}
