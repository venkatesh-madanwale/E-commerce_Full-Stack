export class AddCartDto {
  uid: string;
  pid: string;
  name: string;
  qty?: number;
  price: number;
  pimg?: string;
}